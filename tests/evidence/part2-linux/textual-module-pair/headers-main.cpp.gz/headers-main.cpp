

#include <bits/stdc++.h>

// stdc++.h doesn't include <execution> because of TBB issues;
// FIXME for now let's avoid the problem by suppressing TBB.
#ifdef _PSTL_PAR_BACKEND_TBB
#undef _PSTL_PAR_BACKEND_TBB
#define _PSTL_PAR_BACKEND_SERIAL
#endif
#include <execution>

// Module std does include deprecated library interfaces.
#undef __DEPRECATED
#include <strstream>


#include <nlohmann/json.hpp>
#include "counter.h"
#include "ui_mainwindow.h"

#include <QtCore/QCommandLineParser>
#include <QtCore/QFile>
#include <QtCore/QLibraryInfo>
#include <QtCore/QTimer>
#include <QtCore/QTranslator>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>

#include <cstdio>




int main(int argc, char** argv) {

    QApplication app(argc, argv);

    QCommandLineParser cli;
    cli.addHelpOption();
    cli.addOption({"lang", "UI language: en or zh_CN.", "lang", "zh_CN"});
    cli.addOption({"screenshot", "Save the window to <file> and quit.", "file"});
    cli.process(app);

    // The project's translation (lrelease) and Qt's own (lconvert), both placed
    // under translations/ beside the program by rules-qt.
    const QString dir = QCoreApplication::applicationDirPath() + "/translations";
    QTranslator mine, qts;
    if (cli.value("lang") == "zh_CN") {
        if (mine.load("qt_demo_zh_CN", dir)) QCoreApplication::installTranslator(&mine);
        if (qts.load("qt_zh_CN", dir)) QCoreApplication::installTranslator(&qts);
    }

    QMainWindow window;
    Ui::MainWindow ui;
    ui.setupUi(&window);
    window.setWindowTitle(QCoreApplication::translate("demo", "mcpp Qt demo"));
    ui.title->setText(QCoreApplication::translate("demo", "Built by mcpp with rules-qt"));
    ui.addButton->setText(QCoreApplication::translate("demo", "Add one"));
    ui.resetButton->setText(QCoreApplication::translate("demo", "Reset"));

    // rcc: the text below is embedded in the executable.
    QFile about(":/about.txt");
    if (about.open(QIODevice::ReadOnly)) ui.about->setPlainText(QString::fromUtf8(about.readAll()));

    // moc: Counter's signal drives the label.
    Counter counter;
    auto show = [&](int v) {
        ui.count->setText(QCoreApplication::translate("demo", "Clicked %1 times").arg(v));
    };
    QObject::connect(ui.addButton, &QPushButton::clicked, &counter, &Counter::increment);
    QObject::connect(ui.resetButton, &QPushButton::clicked, &counter, &Counter::reset);
    QObject::connect(&counter, &Counter::changed, show);
    show(0);

    ui.info->setText(QString("Qt %1 · %2 · %3")
                         .arg(qVersion(), QGuiApplication::platformName(),
                              QLibraryInfo::isSharedBuild() ? "shared" : "static"));
    // Qt's own strings, translated by qt_zh_CN.qm.
    ui.buttons->setStandardButtons(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    QObject::connect(ui.buttons, &QDialogButtonBox::accepted, &app, &QApplication::quit);
    QObject::connect(ui.buttons, &QDialogButtonBox::rejected, &app, &QApplication::quit);

    window.show();
    std::printf("qt-demo: Qt %s, platform %s, language %s\n", qVersion(),
                QGuiApplication::platformName().toUtf8().constData(),
                cli.value("lang").toUtf8().constData());

    if (cli.isSet("screenshot")) {
        const QString file = cli.value("screenshot");
        QTimer::singleShot(400, [&] {
            counter.increment();
            counter.increment();
            counter.increment();
            window.grab().save(file);
            std::printf("qt-demo: saved %s\n", file.toUtf8().constData());
            app.quit();
        });
    }
    return app.exec();
}
