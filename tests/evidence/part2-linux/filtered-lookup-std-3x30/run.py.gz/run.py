import json,subprocess,pathlib
r=pathlib.Path(__file__).parent
with (r/"run.log").open("w") as f:
 p=subprocess.run(json.load(open(r/"command.json")),stdout=f,stderr=subprocess.STDOUT)
print("std3x30 exit",p.returncode,flush=True)
raise SystemExit(p.returncode)
