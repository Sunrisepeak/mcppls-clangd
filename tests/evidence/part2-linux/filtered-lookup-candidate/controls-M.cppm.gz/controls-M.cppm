export module M;
export namespace backing {
int vector(int);
int vector(double);
template<class T> T vector_template(T);
}
export namespace api {
using namespace backing;
inline namespace abi { int verifier(int); }
}
