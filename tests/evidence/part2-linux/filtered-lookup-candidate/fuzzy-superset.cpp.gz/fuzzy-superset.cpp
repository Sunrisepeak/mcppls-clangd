#include "FuzzyMatch.h"
#include "llvm/ADT/StringRef.h"
#include <vector>
#include <string>
#include <iostream>
using llvm::StringRef;
static bool Accept(StringRef Name, StringRef Pattern) {
  if (Pattern.size() > 63) return true;
  for (unsigned char C : Name)
    if (C >= 128)
      return true;
  for (unsigned char C : Pattern)
    if (C >= 128)
      return true;
  size_t Pos = 0;
  auto Lower = [](unsigned char C) {
    return C >= 'A' && C <= 'Z' ? C + ('a' - 'A') : C;
  };
  for (unsigned char C : Name)
    if (Pos < Pattern.size() && Lower(C) == Lower(Pattern[Pos]))
      ++Pos;
  return Pos == Pattern.size();
}
static void Generate(std::vector<std::string>& Out, std::string Prefix, int N) {
 Out.push_back(Prefix);
 if (!N) return;
 for(char C : std::string("aA_bB")) Generate(Out, Prefix+C, N-1);
}
int main() {
 std::vector<std::string> Names, Patterns;
 Generate(Names, "", 4); Generate(Patterns, "", 3);
 Names.push_back(std::string(150,'a')); Patterns.push_back(std::string(64,'a')+"z");
 Names.push_back("unique_ptr"); Patterns.push_back("u_p");
 Names.push_back("vector"); Patterns.push_back("vr");
 unsigned Checked=0, Matches=0;
 for(auto &P:Patterns) for(auto &N:Names) {
  ++Checked;
  clang::clangd::FuzzyMatcher F(P);
  if(F.match(N)) {
   ++Matches;
   if(!Accept(N,P)) {std::cerr<<"dropped "<<P<<" / "<<N<<"\n";return 1;}
  }
 }
 std::cout<<"pairs="<<Checked<<" fuzzy_matches="<<Matches<<" dropped=0\n";
}
