import M;
int probe() {
    return api::vector(1);
}
