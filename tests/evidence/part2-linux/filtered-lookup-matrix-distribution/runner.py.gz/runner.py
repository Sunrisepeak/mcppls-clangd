from pathlib import Path
import json,subprocess,hashlib,sys,re
probes=Path('/home/speak/workspace/github/mcppls-clangd/tests/probes');sys.path.insert(0,str(probes))
from completion_insertion import apply,compile_insertion
root=Path(__file__).parent/'matrix-distribution';root.mkdir(exist_ok=True)
contexts=probes/'contexts/qt';cdb=Path('/tmp/mcppls-pch-scan68-build/integrated/qt-cdb/compile_commands.json').read_bytes()
summary={'scope':'Other11 contexts, each3starts x30rounds. All completion replies checked; GCC insertions selected per start/phase: first,last,slowest distinct replies, all expected symbols. Not every reply is compiled. Empty negative contexts have no selected insertion.','engine_sha256':hashlib.sha256((root.parent/'clangd').read_bytes()).hexdigest(),'results':{}}
for context in sorted(contexts.glob('*.json')):
 if context.stem=='std-qualified':continue
 data=json.loads(context.read_text());p=root/context.stem;p.mkdir(exist_ok=True);cache=p/'cdb';cache.mkdir(exist_ok=True)
 if (cache/'.cache').exists() or (p/'report.json').exists():raise SystemExit('refusing to overwrite/reuse '+str(p))
 (cache/'compile_commands.json').write_bytes(cdb)
 args=['python3',str(probes/'project_completion.py'),'--engine',str(root.parent/'clangd'),'--project','/home/speak/test/mcpp/qt-demo','--source','/home/speak/test/mcpp/qt-demo/src/main.cpp','--context-file',str(context),'--starts','3','--rounds','30','--phases','--resources','--output',str(p/'report.json'),'--engine-flag=-resource-dir=/home/speak/workspace/github/mcppls-clangd/build-linux-x64/lib/clang/23','--engine-flag=--compile-commands-dir='+str(cache)]
 (p/'command.json').write_text(json.dumps(args,indent=2)+'\n')
 with (p/'run.log').open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 row={'exit_code':r.returncode};proofs=[]
 if (p/'report.json').exists():
  report=json.load(open(p/'report.json'));row.update(semantic_pass=report['all_semantic_requests_passed'],phases=report['phases'],semantic_counts=report['semantic_counts'])
  if data.get('expected'):
   for start,raw in enumerate(report['raw_results']):
    answers=raw['context_answers'];selected=set()
    for phase in ['cold-open','settled-warm','edited']:
     indices=[i for i,a in enumerate(answers) if a['phase']==phase]
     if indices:selected.update([indices[0],indices[-1],max(indices,key=lambda i:answers[i]['elapsed_ms'])])
    for index in sorted(selected):
     answer=answers[index]
     for name in data['expected']:
      proof={'start':start,'answer':index,'phase':answer['phase'],'symbol':name}
      candidates=[i for i in answer['items'] if re.split(r'[(<]',i.get('filterText',i.get('label','')))[0].strip()==name]
      kind=data.get('kind',{}).get(name)
      if kind is not None:candidates=[i for i in candidates if i.get('kind')==kind]
      try:
       if not candidates:raise ValueError('no actual candidate of required symbol/kind')
       proof['item']=candidates[0];text=apply(answer['draft'],report['position'],candidates[0],data.get('bindings',{}).get(name,{}));proof.update(compile_insertion(Path('/home/speak/test/mcpp/qt-demo'),Path('/home/speak/test/mcpp/qt-demo/src/main.cpp'),text))
      except (ValueError,OSError) as e:proof['error']=str(e)
      proofs.append(proof)
   row['selected_insertions']=len(proofs);row['all_selected_insertions_compiled']=bool(proofs) and all(x.get('exit_code')==0 for x in proofs)
  else:row.update(selected_insertions=0,all_selected_insertions_compiled=None)
  limit=data.get('limit_ms');row['warm_edited_p95_pass']=None if limit is None else all(report['phases'][phase]['p95_ms']<=limit for phase in ['settled-warm','edited'])
 (p/'selected-insertions.json').write_text(json.dumps({'policy':'Per start/phase first,last,slowest distinct replies, all expected symbols; engine timing finished before compilation.','proofs':proofs},indent=2)+'\n')
 summary['results'][context.stem]=row;(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(context.stem,{'exit':r.returncode,'semantics':row.get('semantic_pass'),'insertions':row.get('all_selected_insertions_compiled'),'warm':row.get('phases',{}).get('settled-warm',{}).get('p95_ms'),'edited':row.get('phases',{}).get('edited',{}).get('p95_ms'),'budget_pass':row.get('warm_edited_p95_pass')},flush=True)
raise SystemExit(any(x['exit_code'] or x.get('semantic_pass') is False or x.get('all_selected_insertions_compiled') is False or x.get('warm_edited_p95_pass') is False for x in summary['results'].values()))
