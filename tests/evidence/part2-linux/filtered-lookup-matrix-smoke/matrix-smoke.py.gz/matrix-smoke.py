from pathlib import Path
import json,subprocess,hashlib
root=Path(__file__).parent/'matrix-smoke';root.mkdir(exist_ok=True)
contexts=Path('/home/speak/workspace/github/mcppls-clangd/tests/probes/contexts/qt')
cdb=Path('/tmp/mcppls-pch-scan68-build/integrated/qt-cdb/compile_commands.json').read_bytes()
summary={'scope':'Exploratory other11 contexts;1start x1round, not final distributions. Empty negative contexts have no selected insertion.', 'engine_sha256':hashlib.sha256((root.parent/'clangd').read_bytes()).hexdigest(),'results':{}}
for context in sorted(contexts.glob('*.json')):
 if context.stem=='std-qualified':continue
 data=json.loads(context.read_text());p=root/context.stem;p.mkdir(exist_ok=True);cache=p/'cdb';cache.mkdir(exist_ok=True)
 if (cache/'.cache').exists():raise SystemExit('refusing to reuse '+str(cache))
 (cache/'compile_commands.json').write_bytes(cdb)
 args=['python3','/home/speak/workspace/github/mcppls-clangd/tests/probes/project_completion.py','--engine',str(root.parent/'clangd'),'--project','/home/speak/test/mcpp/qt-demo','--source','/home/speak/test/mcpp/qt-demo/src/main.cpp','--context-file',str(context),'--starts','1','--rounds','1','--phases','--output',str(p/'report.json'),'--engine-flag=-resource-dir=/home/speak/workspace/github/mcppls-clangd/build-linux-x64/lib/clang/23','--engine-flag=--compile-commands-dir='+str(cache)]
 if data.get('expected'):args.append('--compile-insertions')
 (p/'command.json').write_text(json.dumps(args,indent=2)+'\n')
 with (p/'run.log').open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 row={'exit_code':r.returncode}
 if (p/'report.json').exists():
  report=json.load(open(p/'report.json'));row.update(semantic_pass=report['all_semantic_requests_passed'],insertion_pass=report['all_insertions_compiled'] if data.get('expected') else None,phases=report['phases'],semantic_counts=report['semantic_counts'])
 summary['results'][context.stem]=row;(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(context.stem,row,flush=True)
 # Preserve every failed context; independent probes continue to locate scope.
raise SystemExit(any(r['exit_code'] for r in summary['results'].values()))
